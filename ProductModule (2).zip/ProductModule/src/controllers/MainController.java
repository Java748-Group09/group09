package controllers;


import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Blob;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import model.Product;
import service.IProductService;

@Controller
public class MainController {
	
	private IProductService productService;

	public IProductService getProductService() {
		return productService;
	}
	@Autowired
	public void setProductService(IProductService productService) {
		this.productService = productService;
	}
	@Autowired
	SessionFactory sf;
	
	

	
	
	
	//ADDING A PRODUCT
	@RequestMapping(value = "AddProduct")
	public String getProductForm(Model model) {		
		model.addAttribute("product",new Product());
		return "addProduct";
	}
	@RequestMapping(value = "addProductForms", method = RequestMethod.POST)
	public String addingProduct(@ModelAttribute("product") @Valid Product prod, BindingResult result,
		@RequestParam("productImage") MultipartFile file, Model model) {
//		// Binding Result is used if the form that has any error then it will
//		// redirect to the same page without performing any functions
////		if (result.hasErrors()) {
		
////			return "addProduct";}
	System.out.println(result.toString());
		System.out.println("File:" + file.getName());
		System.out.println("ContentType:" + file.getContentType());
//		
		try {
				byte[ ] b =file.getBytes();	
				Session session = sf.openSession();
				Blob blob= Hibernate.getLobCreator(session).createBlob(b);
				
			
		} catch (IOException e) {
			e.printStackTrace();
		}
System.out.println(result.toString());
System.out.println("product being added :" + prod);
	productService.addProduct(prod);
//	Path path = Paths
//		.get( "D:/EMI Repos/EMICardManagement1/WebContent/resources/img/products/"
//					+ prod.getProductName() + ".jpg");
//	
//	MultipartFile image = (MultipartFile) prod.getProductImage();
//	try {
//		image.transferTo(new File(path.toString()));
//		//image.transferTo(new File(path.toString()));
//		
//	} catch (IllegalStateException e) {
//		e.printStackTrace();
//	} catch (IOException e) {
//		
//		e.printStackTrace();
//	}
	
	
	
	
	
//		MultipartFile image = prod.getProductImage();
//		if (image != null && !image.isEmpty()) {
//			Path path = Paths
//				.get( "D:/EMI Repos/EMICardManagement1/WebContent/resources/img/products"
//							+ prod.getProductId() + ".jpg");
//
//		try {
//			image.transferTo(new File(path.toString()));
//		} catch (IllegalStateException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		
		return "redirect:/ListProducts";
		
	}
	
	
	
	
	

	
	
	@RequestMapping("ListProducts") 
	public ModelAndView getAllProducts() {
		  List<Product> products = productService.getAllProducts(); 
		  return new ModelAndView("productList", "products", products);
		  }

	

	
//	@RequestMapping(value = "/admin/editProduct", method = RequestMethod.POST)
//	public String editProduct(@ModelAttribute(value = "editProductObj") Product product) {
//		System.out.println("here");
//		productService.editProduct(product);
//		return "redirect:/productList";
//	}
	
//	@RequestMapping(value = "/editProductbyAdmin",method = RequestMethod.POST)
//	public String editprod(@ModelAttribute("editProductObj") Product product, BindingResult r) {
//		System.out.println(r.toString());
//		productService.editProduct(product);
//		return "productList";	
//			}
	
	
	//EDIT PRODUCT BY ADMIN
	@RequestMapping(value = "/admin/product/editProduct/{productId}")
	public ModelAndView getEditForm(@PathVariable(value = "productId") Integer productId) {
		Product product = productService.getProductById(productId);
		System.out.println("ghhh");
		return new ModelAndView("editProduct", "editProductObj", product);
	}
	
	
	
	@RequestMapping(value = "/trying",method = RequestMethod.POST)
	public String trying(@ModelAttribute("editProductObj") Product p,BindingResult r) {
		System.out.println(r.toString());
		System.out.println(p);
		productService.editProduct(p);
		return "redirect:/ListProducts";
		
	}
	
	
	
	//DELETING A PRODUCT BY ADMIN
	
	@RequestMapping("admin/product/delete/{productId}")
	public String deleteProduct(@PathVariable(value = "productId") Integer productId) {

//	
//		Path path = Paths.get("C:/Users/Ismail/workspace/ShoppingCart/src/main/webapp/WEB-INF/resource/images/products/"
//				+ productId + ".jpg");
//
//		if (Files.exists(path)) {
//			try {
//				Files.delete(path);
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}

		productService.deleteProduct(productId);
		
		return "redirect:/ListProducts";
	}


}
