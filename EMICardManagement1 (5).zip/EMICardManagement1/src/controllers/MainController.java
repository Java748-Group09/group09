package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;



import model.Address;
import model.Bank;
import model.Customer;
import model.EMICard;
import model.User;
import service.CustomerService;


@Controller
@SessionAttributes(value = "sessionuser")
public class MainController {
	private CustomerService customerService;
	//private UserService userService;


	@Autowired
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}


	
	
	// FOR LOGIN AND LOGIN FORM
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	public String indexes() {
		return "login";
	}
	
	@RequestMapping(value = "/LoginForms", method = RequestMethod.POST)
	public ModelAndView loginpro(HttpServletRequest request, HttpServletResponse response,
	@ModelAttribute("login") Customer u, BindingResult result, Model model) {
		ModelAndView mav = null;
		String username=request.getParameter("email");
		String password=request.getParameter("password");
		System.out.println("Username is: "+ username+ " Password is: "+password);
		if(customerService.verifyUser(username,password))
		{
			mav = new ModelAndView("loginsuccess");   	
		}
		else
		{
			mav = new ModelAndView("loginerror");
		}
		return mav;
		}
	

	
	
	//FOR REGISTRATION AND REGISTRATION FORM
	@RequestMapping(value = "/RegisterSpring", method = RequestMethod.GET)
	public String regSpring(Model model) {
		model.addAttribute("customer",new Customer());
		return "register";
		}
	
	 @RequestMapping(value = "/RegisterFormsSpring", method = RequestMethod.POST)
	    public String validateregistrationPage1(@Valid @ModelAttribute("customer") Customer customer,
	    		BindingResult bindingResult,Model model) {
		 	System.out.println(customer);
		    customerService.addCustomer(customer);
		    return "regSuccess";
	 	}
	 
	 
	 
 
	 
	}
