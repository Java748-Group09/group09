package controllers;


import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import model.Product;
import service.IProductService;

@Controller
public class MainController {
	
	private IProductService productService;

	public IProductService getProductService() {
		return productService;
	}
	@Autowired
	public void setProductService(IProductService productService) {
		this.productService = productService;
	}
	
	
//	
//	@Bean
//	public MultipartResolver multipartResolver() {
//	CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
//		multipartResolver.setMaxUploadSize(10240000);
//		return multipartResolver;
//}
	
	
	@RequestMapping(value = "AddProduct")
	public String getProductForm(Model model) {
		
		model.addAttribute("product",new Product());
		// New Arrivals
		 ///set the category as 1 for the Book book
		//product.setProductCategory("Android");
		//model.addAttribute("productFormObj", product);
		return "addProduct";
	}

	@RequestMapping(value = "addProductForms", method = RequestMethod.POST)
	public String addingProduct(@ModelAttribute("product") @Valid Product prod, BindingResult result,
		 Model model) {
//		// Binding Result is used if the form that has any error then it will
//		// redirect to the same page without performing any functions
////		if (result.hasErrors()) {
////			return "addProduct";}
	
//		System.out.println("File:" + file.getName());
//		System.out.println("ContentType:" + file.getContentType());
//		
//		try {
//			Blob blob = Hibernate.getLobCreator(sessionfactory.getCurrentSession()).createBlob((file.getInputStream()));
//
//			//prod.setFilename(file.getOriginalFilename());
//			//prod.setContent(blob);
//			//prod.setContentType(file.getContentType());
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
System.out.println(result.toString());
System.out.println("product being added :" + prod);
	productService.addProduct(prod);
//		MultipartFile image = prod.getProductImage();
//		if (image != null && !image.isEmpty()) {
//			Path path = Paths
//				.get( "D:/EMI Repos/EMICardManagement1/WebContent/resources/img/products"
//							+ prod.getProductId() + ".jpg");
//
//		try {
//			image.transferTo(new File(path.toString()));
//		} catch (IllegalStateException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		
		return "productAddSuccess";
	}

	
	
	

}
